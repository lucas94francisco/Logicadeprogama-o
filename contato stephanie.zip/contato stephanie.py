x={"nome" :"Stephanie", "idade":26, "telefone" :31999813223, "email":"stephanie.costab@outlook.com"}
print(x)